package net.skhu.dto;

public class Department {
	int id;
	String d_name;
	String d_office;
	String d_office_tel;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getD_name() {
		return d_name;
	}
	public void setD_name(String d_name) {
		this.d_name = d_name;
	}
	public String getD_office() {
		return d_office;
	}
	public void setD_office(String d_office) {
		this.d_office = d_office;
	}
	public String getD_office_tel() {
		return d_office_tel;
	}
	public void setD_office_tel(String d_office_tel) {
		this.d_office_tel = d_office_tel;
	}

}

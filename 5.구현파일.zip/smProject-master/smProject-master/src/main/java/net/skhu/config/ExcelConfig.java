package net.skhu.config;

public class ExcelConfig {

    public static final String FILE_NAME = "fileName";
    public static final String HEAD = "head";
    public static final String BODY = "body";
    public static final String XLS = "xls";
    public static final String XLSX = "xlsx";

}